for (i = 0; i != 16; i++)
{
	a = a + c;
}